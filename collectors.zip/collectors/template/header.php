<?php error_reporting(0);?>

<!DOCTYPE HTML>
<head>
    <title>Mydigitalgarden</title>
    <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="menu">
        <?php include("./widgets/menu.php"); ?>
    </div>
    <div class="container">
        <a class="logo" href="index.php"><img src="images/digi.png" alt="VisualUpload"></a>
        <span class="right" >
            <?php include("./widgets/login.php"); ?>
        </span>
        <div class="main">
