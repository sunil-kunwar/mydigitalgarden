	</div>
</div>
<div class="footer">
	&copy; <a href="http://www.mydigitalgarden.com">mydigitalgarden</a> 2019. All rights reserved.
	<span class="right">"Film" graphic courtesy of sandeep virdi at <a href="http://freedigitalphotos.net/images/view_photog.php?photogid=587">freedigitalphotos.net</a></span>
</div>
</body>
</html>