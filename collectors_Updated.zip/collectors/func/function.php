<?php

   
    function add_plant($conn, $plant_name, $plant_scientific_name, $number_of_plant, $plant_image){
		$query = mysqli_query($conn, "INSERT INTO plants VALUES('','$plant_name', '$plant_scientific_name','$number_of_plant', '$plant_image')");
    }
	function add_group($conn, $group_name, $group_image, $plants_id){
		$query = mysqli_query($conn, "INSERT INTO groups VALUES('','$group_name', '$group_image','$plants_id')");
    }

    
?>