<?php

   
    function add_plant($conn, $plant_name, $species, $plant_scientific_name, $popular_name, $family, $genera, $number_of_plant, $description, $comment, $age, $add_date){
		$query = mysqli_query($conn, "INSERT INTO plants VALUES('','$plant_name', '$species', '$plant_scientific_name', '$popular_name', '$family', '$genera', '$number_of_plant', '$description','$comment', '$age', '$add_date')");
    }
	function add_group($conn, $group_name, $group_image, $plants_id){
		$query = mysqli_query($conn, "INSERT INTO groups VALUES('','$group_name', '$group_image','$plants_id')");
    }

    
?>