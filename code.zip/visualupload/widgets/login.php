<?php

if(isset($_POST['submit']))
{
    if(isset($_POST['login_email'], $_POST['login_password'])){
        $login_email = $_POST['login_email'];
        $login_password = $_POST['login_password'];
    }

    $errors = array();

    if(empty($login_email) || empty($login_password)){
        $errors[] = 'Email and password required';
    }
    else{
        $login = login_check($conn, $login_email, $login_password);
        if($login == false){
            $errors[] = 'Unable to log you in'; 
        }
        else{
             $_SESSION['user_id'] = $login;
            header('Location: home.php');
            exit();
        }        
    }
    }
	
?>	
	<div class="account-login content">
	<?php if(!empty($errors)){
        foreach($errors as $error){ ?>
           <div class="alert alert-danger">
					  <strong>Danger!</strong> <?php echo $error;?>
					</div>
      <?php  }                
    } ?>
       <form action="" method="post">
			<h2>Log In Here</h2>
			<div class="form-group">
				<label for="login_email">Email address:</label>
				<input type="email" class="form-control" id="login_email" name="login_email">
			</div>
			<div class="form-group">
				<label for="login_password">Password:</label>
				<input type="password" class="form-control" id="login_password" name="login_password">
			</div>
			<button type="submit"  name="submit" class="btn btn-primary">Log in</button>
		</form>
	</div>	
		
		
		



