 <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; <a href="http://www.phpacademy.org">www.mydigitalgarden.com</a> 2019. All rights reserved.<span class="right">"Film" graphic <a href="http://freedigitalphotos.net/images/view_photog.php?photogid=587">freedigitalphotos.net</a></span></p>
    </div>
    <!-- /.container -->
  </footer>
<?php
$expireAfter = 2;
$secondsInactive = time() - $_SESSION['msg'];
$secondsInactivede = time() - $_SESSION['error'];
$expireAfterSeconds = $expireAfter * 60;
if($secondsInactive >= $expireAfterSeconds){	
	 unset($_SESSION['msg']);
}
if($secondsInactivede >= $expireAfterSeconds){	
	 unset($_SESSION['error']);
}
?>
<!-- Bootstrap core JavaScript -->
  <script src="./js/jquery.min.js"></script>
  <script src="./js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="./js/jquery-ui.min.js"></script>  

<script>
 $( function() {
	$( "#add_date" ).datepicker({
	  changeMonth: true,
	  changeYear: true,
	  dateFormat: 'dd-mm-yy'
	});
  });	$( function() {
	$( "#date_added" ).datepicker({
	  changeMonth: true,
	  changeYear: true,
	  dateFormat: 'dd-mm-yy'
	});
  });	
  $("#add_plant").click(function(){
  $("#add_plant_form").toggle(); $("#add_group_form").hide();
});
$("#add_group").click(function(){
  $("#add_group_form").toggle(); $("#add_plant_form").hide();
});
</script>
</body>

</html>
